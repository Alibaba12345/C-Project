


int max_array(int a[], int num_elements);
int min_array(int a[], int num_elements);